dic = {"caoxiao":1}
print("caoxia" in dic)